package com.example.hospital_doctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
